Thor RPG Art Prototype (Godot 4)

Approved pixel-art assets integrated into a playable Godot source project.
Open godot/project.godot with Godot 4.4 or newer, then press F6/F5 to run.
Keyboard: arrow keys to move, space to attack. Mobile: left virtual joystick, right attack.
This is a SOURCE PROJECT ZIP, not an Android APK. Godot Android export requires SDK and export templates.
The pixel-art asset sheet was split into sprites and background made transparent programmatically. Some edges may require manual cleanup. The player direction frames are visual approximations, not full 8-direction animation.
