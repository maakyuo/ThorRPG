extends Node2D

const WORLD := Vector2(2200, 1500)
const JOBS := ["전사", "마법사", "궁수", "암살자"]
const STATS := ["근력", "민첩", "지능", "체력", "마력"]
const SKILLS := {"전사":["돌진 베기","회전 베기","전투의 함성","반격 태세","대지 가르기"],"마법사":["화염구","얼음 화살","마력 보호막","바람 칼날","마력 폭발"],"궁수":["속사","관통 사격","회피 사격","독화살","매의 눈"],"암살자":["기습","출혈 베기","그림자 이동","연속 참격","암살의 마음가짐"]}
const ITEMS := [{"name":"낡은 철검","slot":"무기","job":"전사","atk":8},{"name":"초보자의 지팡이","slot":"무기","job":"마법사","magic":8},{"name":"낡은 단궁","slot":"무기","job":"궁수","atk":7},{"name":"낡은 단검","slot":"무기","job":"암살자","atk":6},{"name":"천 상의","slot":"상의","def":2},{"name":"천 하의","slot":"하의","def":2},{"name":"가죽 장갑","slot":"장갑","def":1},{"name":"가죽 신발","slot":"신발","def":1}]
const MONSTERS := [{"name":"토끼","level":1,"hp":25.0,"atk":3.0,"def":0.0,"xp":15,"texture":"rabbit"},{"name":"뿔토끼","level":3,"hp":48.0,"atk":7.0,"def":2.0,"xp":30,"texture":"horn_rabbit"},{"name":"늑대","level":5,"hp":75.0,"atk":11.0,"def":4.0,"xp":50,"texture":"wolf"},{"name":"고블린","level":10,"hp":145.0,"atk":19.0,"def":8.0,"xp":110,"texture":"goblin"}]
var textures := {}
var name_text := ""
var job := ""
var stage := 0
var menu := ""
var stats := {"근력":1,"민첩":1,"지능":1,"체력":1,"마력":1}
var points := 50
var equipped := {"무기":-1,"상의":-1,"하의":-1,"장갑":-1,"신발":-1}
var level := 1
var xp := 0
var hp := 110.0
var mp := 110.0
var player := Vector2(1040,870)
var facing := Vector2.DOWN
var moving := false
var elapsed := 0.0
var attack_cd := 0.0
var mobs: Array[Dictionary] = []
var ui: Control
var panel: PanelContainer
var contents: VBoxContainer
var name_entry: LineEdit
var touch_id := -1
var touch_origin := Vector2.ZERO
var touch_move := Vector2.ZERO
var message := ""
var message_timer := 0.0

func _ready() -> void:
 for path in DirAccess.get_files_at("res://assets"):
  if path.ends_with(".png"):
   textures[path.trim_suffix(".png")] = load("res://assets/"+path)
 _load()
 for i in 8:
  var kind: int = i / 2
  var m: Dictionary = MONSTERS[kind].duplicate(true)
  m["pos"] = Vector2(400+(i%4)*440, 370+(i/4)*730)
  m["home"] = m["pos"]
  m["max_hp"] = m["hp"]
  m["respawn"] = 0.0
  m["attack_cd"] = 0.0
  mobs.append(m)
 _ui()
 _refresh()

func _ui() -> void:
 ui = Control.new()
 ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 ui.mouse_filter = Control.MOUSE_FILTER_PASS
 add_child(ui)
 var bar := HBoxContainer.new()
 bar.set_anchors_preset(Control.PRESET_TOP_RIGHT)
 bar.offset_left = -440
 bar.offset_right = -8
 bar.offset_top = 8
 bar.offset_bottom = 54
 ui.add_child(bar)
 for title in ["인벤토리","스탯","스킬"]:
  var b := Button.new()
  b.text = title
  b.custom_minimum_size = Vector2(135,46)
  b.pressed.connect(_toggle.bind(title))
  bar.add_child(b)
 panel = PanelContainer.new()
 panel.set_anchors_preset(Control.PRESET_CENTER)
 panel.offset_left = -285
 panel.offset_right = 285
 panel.offset_top = -235
 panel.offset_bottom = 235
 ui.add_child(panel)
 var scroll := ScrollContainer.new()
 scroll.custom_minimum_size = Vector2(560,460)
 panel.add_child(scroll)
 contents = VBoxContainer.new()
 contents.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 contents.add_theme_constant_override("separation",8)
 scroll.add_child(contents)

func _label(value: String) -> void:
 var l := Label.new()
 l.text = value
 l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 l.add_theme_font_size_override("font_size",20)
 contents.add_child(l)

func _button(value: String, callback: Callable) -> void:
 var b := Button.new()
 b.text = value
 b.custom_minimum_size.y = 44
 b.pressed.connect(callback)
 contents.add_child(b)

func _refresh() -> void:
 for node in contents.get_children():
  contents.remove_child(node)
  node.queue_free()
 panel.visible = stage < 3 or menu != ""
 if stage == 0:
  _label("THOR RPG  |  이름 설정")
  name_entry = LineEdit.new()
  name_entry.max_length = 16
  name_entry.placeholder_text = "캐릭터 이름"
  name_entry.text = name_text
  contents.add_child(name_entry)
  _button("다음",_confirm_name)
 elif stage == 1:
  _label("기본 직업 선택")
  for j in JOBS:
   _button(j,_choose_job.bind(j))
 elif stage == 2:
  _label("%s / %s  |  남은 포인트 %d" % [name_text,job,points])
  for key in STATS:
   _button("%s  %d  [+1]" % [key,stats[key]],_add_stat.bind(key))
  _button("게임 시작",_start)
 elif menu == "인벤토리":
  _label("일반 등급 장비  |  터치하여 착용")
  for i in ITEMS.size():
   var item: Dictionary = ITEMS[i]
   var active: bool = int(equipped[str(item["slot"])]) == i
   _button("%s %s" % [item["name"],"[착용]" if active else ""],_equip.bind(i))
  _button("닫기",_close)
 elif menu == "스탯":
  _label("Lv.%d / 남은 포인트 %d" % [level,points])
  for key in STATS:
   _button("%s %d [+1]" % [key,stats[key]],_add_stat.bind(key))
  _label("HP %d / MP %d / 방어 %d" % [int(_max_hp()),int(_max_mp()),int(_defense())])
  _button("닫기",_close)
 elif menu == "스킬":
  _label("%s 스킬창 (표시 전용)" % job)
  for skill in SKILLS[job]:
   _label("◇ %s  Lv.1  [미구현]" % skill)
  _button("닫기",_close)

func _confirm_name() -> void:
 name_text = name_entry.text.strip_edges()
 if name_text.is_empty():
  return
 stage = 1
 _refresh()
func _choose_job(j: String) -> void:
 job = j
 stage = 2
 _refresh()
func _start() -> void:
 stage = 3
 hp = _max_hp()
 mp = _max_mp()
 _save()
 _refresh()
func _toggle(t: String) -> void:
 if stage != 3:
  return
 menu = "" if menu == t else t
 _refresh()
func _close() -> void:
 menu = ""
 _refresh()
func _add_stat(key: String) -> void:
 if points <= 0:
  return
 stats[key] += 1
 points -= 1
 hp = minf(_max_hp(),hp+(10 if key == "체력" else 0))
 mp = minf(_max_mp(),mp+(10 if key == "마력" else 0))
 _save()
 _refresh()
func _equip(i: int) -> void:
 var item: Dictionary = ITEMS[i]
 if item.has("job") and item["job"] != job:
  message = "%s 전용 무기" % item["job"]
  message_timer = 2.0
  return
 var slot: String = item["slot"]
 equipped[slot] = -1 if equipped[slot] == i else i
 _save()
 _refresh()
func _max_hp() -> float:
 return 100.0+float(stats["체력"])*10.0
func _max_mp() -> float:
 return 100.0+float(stats["마력"])*10.0
func _defense() -> float:
 var total := float(stats["체력"])
 for slot in ["상의","하의","장갑","신발"]:
  var idx: int = equipped[slot]
  if idx >= 0:
   total += float(ITEMS[idx].get("def",0))
 return total
func _attack_power() -> float:
 var idx: int = equipped["무기"]
 var base := 0.0
 if idx >= 0:
  base = float(ITEMS[idx].get("magic",0)) if job == "마법사" else float(ITEMS[idx].get("atk",0))
 var stat := float(stats["지능"]) if job == "마법사" else float(stats["근력"])
 return stat+base*(1.0+stat*0.005)

func _process(delta: float) -> void:
 elapsed += delta
 message_timer = maxf(0.0,message_timer-delta)
 if stage != 3:
  queue_redraw()
  return
 attack_cd = maxf(0.0,attack_cd-delta)
 mp = minf(_max_mp(),mp+float(stats["마력"])*0.1*delta)
 var move := Input.get_vector("ui_left","ui_right","ui_up","ui_down")
 if touch_move.length()>0.1:
  move = touch_move
 moving = move.length()>0.1 and menu == ""
 if moving:
  facing = move.normalized()
  player = (player+facing*175.0*(1.0+float(stats["민첩"])*0.001)*delta).clamp(Vector2(40,40),WORLD-Vector2(40,40))
 if Input.is_key_pressed(KEY_SPACE):
  _attack()
 for m in mobs:
  if float(m["hp"]) <= 0:
   m["respawn"] = float(m["respawn"])-delta
   if m["respawn"]<=0:
    m["hp"] = m["max_hp"]
    m["pos"] = m["home"]
   continue
  var offset: Vector2 = player-m["pos"]
  if offset.length()<220 and offset.length()>52 and menu=="":
   m["pos"] += offset.normalized()*delta*(35.0+float(m["level"])*5.0)
  m["attack_cd"] = maxf(0.0,float(m["attack_cd"])-delta)
  if offset.length()<=52 and m["attack_cd"]<=0 and menu=="":
   m["attack_cd"] = 1.6
   if randf()>minf(0.9,0.03+float(stats["민첩"])*0.0002):
    hp -= maxf(1.0,float(m["atk"])*100.0/(100.0+_defense()))
    if hp<=0:
     hp = _max_hp()
     player = Vector2(1040,870)
     message = "쓰러졌습니다. 시작 위치에서 부활"
     message_timer = 3.0
 queue_redraw()

func _attack() -> void:
 if stage!=3 or menu!="" or attack_cd>0:
  return
 attack_cd = 0.4
 for m in mobs:
  if m["hp"]<=0:
   continue
  var offset: Vector2 = m["pos"]-player
  if offset.length()>110 or (offset.length()>30 and facing.dot(offset.normalized())<0):
   continue
  var damage := maxf(1.0,_attack_power()*100.0/(100.0+float(m["def"])))
  if randf()<0.05:
   damage *= 1.5
  m["hp"] = float(m["hp"])-damage
  if m["hp"]<=0:
   m["respawn"] = 12.0
   xp += int(m["xp"])
   message = "%s 처치! 경험치 +%d" % [m["name"],m["xp"]]
   message_timer = 2.5
   while xp>=level*100:
    xp -= level*100
    level += 1
    points += 5
    hp = _max_hp()
    mp = _max_mp()
   _save()

func _unhandled_input(event: InputEvent) -> void:
 if stage!=3 or menu!="":
  return
 if event is InputEventScreenTouch:
  var p: Vector2 = event.position
  var s := get_viewport_rect().size
  if event.pressed:
   if p.x<s.x*0.4 and p.y>s.y*0.5:
    touch_id = event.index
    touch_origin = p
   elif p.x>s.x*0.7 and p.y>s.y*0.55:
    _attack()
  elif event.index==touch_id:
   touch_id = -1
   touch_move = Vector2.ZERO
 elif event is InputEventScreenDrag and event.index==touch_id:
  touch_move = ((event.position-touch_origin)/70.0).limit_length(1.0)

func _sprite(key: String, pos: Vector2, size: Vector2) -> void:
 if not textures.has(key):
  return
 var tex: Texture2D = textures[key]
 draw_texture_rect(tex,Rect2(pos-size*0.5,size),false)

func _draw() -> void:
 var s := get_viewport_rect().size
 var cam := (player-s*0.5).clamp(Vector2.ZERO,WORLD-s)
 draw_rect(Rect2(Vector2.ZERO,s),Color("#76a85e"))
 for x in range(maxi(0,int(cam.x/96.0)),int((cam.x+s.x)/96.0)+2):
  for y in range(maxi(0,int(cam.y/96.0)),int((cam.y+s.y)/96.0)+2):
   var pos := Vector2(x*96,y*96)-cam
   _sprite("grass",pos+Vector2(48,48),Vector2(100,100))
   if (x*7+y*11)%13==0:
    _sprite("grass_0",pos+Vector2(30,38),Vector2(38,38))
   if (x*5+y*3)%19==0:
    _sprite("flowers_0",pos+Vector2(70,68),Vector2(38,38))
 for x in 10:
  _sprite("dirt",Vector2(550+x*95,680)-cam,Vector2(100,100))
 _sprite("house",Vector2(1060,505)-cam,Vector2(350,375))
 for i in 40:
  var p := Vector2(150+(i*173)%1850,120+(i*109)%1250)
  if p.distance_to(Vector2(1060,505))<320 or p.distance_to(Vector2(1040,870))<160:
   continue
  _sprite("tree_%d"%(i%3),p-cam,Vector2(110,140))
 for i in 16:
  var p := Vector2(240+(i*251)%1700,240+(i*211)%1050)
  if p.distance_to(Vector2(1040,870))<130:
   continue
  _sprite("bush_%d"%(i%2),p-cam,Vector2(58,43))
 for i in 3:
  var p := Vector2(880+i*110,750+(i%2)*60)-cam
  _sprite("npc_%d"%i,p,Vector2(74,105))
  draw_string(ThemeDB.fallback_font,p+Vector2(-35,-60),["마을 주민","여행 상인","숲지기"][i],HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color.WHITE)
 for m in mobs:
  if m["hp"]<=0:
   continue
  var p: Vector2 = m["pos"]-cam
  _sprite(m["texture"],p,Vector2(90,85) if m["level"]<5 else Vector2(115,100))
  draw_string(ThemeDB.fallback_font,p+Vector2(-40,-56),"Lv.%d %s"%[m["level"],m["name"]],HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color.WHITE)
  draw_rect(Rect2(p+Vector2(-38,-48),Vector2(76,4)),Color("#352d30"))
  draw_rect(Rect2(p+Vector2(-38,-48),Vector2(76*float(m["hp"])/float(m["max_hp"]),4)),Color("#d7605a"))
 var direction := 0
 if absf(facing.x)>absf(facing.y):
  direction = 1 if facing.x<0 else 2
 elif facing.y<0:
  direction = 3
 var frame := int(elapsed*7.0)%4 if moving else 0
 _sprite("player_%d_%d"%[direction,frame],player-cam,Vector2(80,118))
 if attack_cd>0.25:
  draw_arc(player-cam,80,atan2(facing.y,facing.x)-0.7,atan2(facing.y,facing.x)+0.7,16,Color("#ffe6aa"),4)
 if stage==3:
  draw_rect(Rect2(8,8,265,72),Color(0.07,0.13,0.1,0.83))
  var font := ThemeDB.fallback_font
  draw_string(font,Vector2(17,29),"%s  |  %s Lv.%d"%[name_text,job,level],HORIZONTAL_ALIGNMENT_LEFT,-1,17,Color.WHITE)
  draw_string(font,Vector2(17,51),"HP %d/%d  MP %d/%d"%[int(hp),int(_max_hp()),int(mp),int(_max_mp())],HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color.WHITE)
  draw_string(font,Vector2(17,70),"EXP %d/%d  포인트 %d"%[xp,level*100,points],HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color.WHITE)
  if message_timer>0:
   draw_string(font,Vector2(s.x*0.3,90),message,HORIZONTAL_ALIGNMENT_LEFT,-1,19,Color.WHITE)
  if menu=="":
   draw_circle(Vector2(88,s.y-82),65,Color(0.1,0.18,0.16,0.5))
   draw_circle(Vector2(s.x-75,s.y-77),50,Color(0.3,0.16,0.14,0.7))
   draw_string(font,Vector2(s.x-95,s.y-69),"공격",HORIZONTAL_ALIGNMENT_LEFT,-1,22,Color.WHITE)

func _save() -> void:
 if stage!=3:
  return
 var data := {"name":name_text,"job":job,"stats":stats,"points":points,"equipped":equipped,"level":level,"xp":xp,"hp":hp,"mp":mp,"pos":[player.x,player.y]}
 var file := FileAccess.open("user://thor_art_v01.json",FileAccess.WRITE)
 if file:
  file.store_string(JSON.stringify(data))
func _load() -> void:
 if not FileAccess.file_exists("user://thor_art_v01.json"):
  return
 var file := FileAccess.open("user://thor_art_v01.json",FileAccess.READ)
 if not file:
  return
 var d = JSON.parse_string(file.get_as_text())
 if typeof(d)!=TYPE_DICTIONARY or not JOBS.has(str(d.get("job",""))):
  return
 name_text = str(d.get("name",""))
 job = str(d["job"])
 if name_text.is_empty():
  return
 stage = 3
 level = maxi(1,int(d.get("level",1)))
 xp = int(d.get("xp",0))
 points = int(d.get("points",50))
 for key in STATS:
  stats[key] = maxi(1,int(d.get("stats",{}).get(key,1)))
 for slot in equipped:
  var index: int = int(d.get("equipped",{}).get(slot,-1))
  equipped[slot] = index if index>=0 and index<ITEMS.size() and ITEMS[index]["slot"]==slot else -1
 hp = clampf(float(d.get("hp",_max_hp())),1.0,_max_hp())
 mp = clampf(float(d.get("mp",_max_mp())),0.0,_max_mp())
 var pos: Array = d.get("pos",[1040,870])
 player = Vector2(float(pos[0]),float(pos[1]))
